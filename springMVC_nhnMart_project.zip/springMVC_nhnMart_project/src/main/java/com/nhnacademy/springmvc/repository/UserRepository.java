package com.nhnacademy.springmvc.repository;

import com.nhnacademy.springmvc.domain.User;
import com.nhnacademy.springmvc.domain.UserType;

public interface UserRepository {
    boolean exists(String id);
    boolean matches(String id, String password, UserType userType);

    User getUser(String id);

    User addUser(String id, String password, int age, String name , UserType userType);


    void modify(User user);

}
