package com.nhnacademy.springmvc.domain;

import lombok.Getter;

public class User {
    @Getter
    private String id;
    @Getter
    private String password;
    @Getter
    private int age;
    @Getter
    private String name;
    @Getter
    private UserType userType;


    public static User create(String id, String password, int age, String name ,UserType userType) {
        return new User(id, password, age, name, userType);
    }

    public User(String id, String password, int age, String name, UserType userType) {
        this.id = id;
        this.password = password;
        this.age = age;
        this.name = name;
        this.userType = userType;
    }
}
