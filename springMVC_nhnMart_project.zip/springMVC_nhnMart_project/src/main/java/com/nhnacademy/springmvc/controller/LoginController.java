package com.nhnacademy.springmvc.controller;


import com.nhnacademy.springmvc.domain.User;
import com.nhnacademy.springmvc.domain.UserType;
import com.nhnacademy.springmvc.repository.UserRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@Controller
@Slf4j
public class LoginController {
    private final UserRepository userRepository;

    public LoginController(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    @GetMapping("/login")
    public String login(@CookieValue(value = "SESSION", required = false) String session,
                        Model model) {
        if (StringUtils.hasText(session)) {
            model.addAttribute("id", session);
            User user = userRepository.getUser(session);
            if(session.equals(user.getId())){
                if(user.getUserType().equals(UserType.CS)){
                    return "loginSuccessCS";
                }
                return "loginSuccessCustomer";
            }
            return "loginForm";
        } else {
            return "loginForm";
        }
    }

    @GetMapping("/logout")
    public String logout(HttpServletRequest request, HttpServletResponse response) {
        HttpSession session = request.getSession();
        if (session != null) {
            Cookie cookie = new Cookie("SESSION", null);
            response.addCookie(cookie);
            session.invalidate();
        }
        return "loginForm";
    }

    @PostMapping("/login")
    public String doLogin(@RequestParam("id") String id,
                          @RequestParam("pwd") String pwd,
                          HttpServletRequest request,
                          HttpServletResponse response,
                          ModelMap modelMap) {
        String userTypestr = (request.getParameter("userType"));
        UserType userType = UserType.valueOf(userTypestr.toUpperCase());
        if (userRepository.matches(id, pwd, userType)) {
            HttpSession session = request.getSession(true);
            session.setAttribute(id, id);
            Cookie cookie = new Cookie("SESSION", String.valueOf(session.getAttribute(id)));
            response.addCookie(cookie);

            modelMap.put("id", id);
            if (userType.equals(UserType.CS)) {
                return "loginSuccessCS";
            }
            return "loginSuccessCustomer";
        } else {
            return "redirect:/login";
        }
    }

}
