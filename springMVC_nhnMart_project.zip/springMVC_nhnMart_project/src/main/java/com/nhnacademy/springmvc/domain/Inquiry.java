package com.nhnacademy.springmvc.domain;

import lombok.Getter;
import lombok.Setter;
import org.springframework.web.multipart.MultipartFile;

public class Inquiry {
    @Getter
    @Setter
    private long id;

    @Getter
    private final String title;
    @Getter
    private final MultipartFile file;

    @Getter
    private final String content;

    public static Inquiry create(long id, String title, MultipartFile file, String content) {
        return new Inquiry(id, title, file, content);
    }

    private Inquiry (long id, String title, MultipartFile file, String content) {
        this.id = id;
        this.title = title;
        this.file = file;
        this.content = content;
    }
}
