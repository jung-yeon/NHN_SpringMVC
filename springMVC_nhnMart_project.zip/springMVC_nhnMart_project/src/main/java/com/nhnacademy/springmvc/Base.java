package com.nhnacademy.springmvc;

public interface Base {
}
