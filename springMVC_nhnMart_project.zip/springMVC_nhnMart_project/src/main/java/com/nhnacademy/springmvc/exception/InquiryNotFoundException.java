package com.nhnacademy.springmvc.exception;

public class InquiryNotFoundException extends Exception{
}
