package com.nhnacademy.springmvc.repository;

import com.nhnacademy.springmvc.domain.User;
import com.nhnacademy.springmvc.domain.UserType;
import com.nhnacademy.springmvc.exception.UserAlreadyExistsException;
import com.nhnacademy.springmvc.exception.UserNotFoundException;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;

public class UserRepositoryImpl implements UserRepository {
    private final Map<String, User> userMap = new HashMap<>();

    @Override
    public boolean exists(String id) {
        return userMap.containsKey(id);
    }

    @Override
    public boolean matches(String id, String password, UserType userType) {
        User user = userMap.get(id);
        if(user.getPassword().equals(password) && user.getUserType().equals(userType)) {
            return true;
        }
        return false;

    }

    @Override
    public User getUser(String id) {
        return exists(id) ? userMap.get(id) : null;
    }



    @Override
    public User addUser(String id, String password, int age, String name , UserType userType) {
        if (exists(id)) {
            throw new UserAlreadyExistsException();
        }

        User user = User.create(id, password, age, name, userType);

        userMap.put(id, user);

        return user;
    }

    @Override
    public void modify(User user) {
        User dbUser = getUser(user.getId());
        if (Objects.isNull(dbUser)) {
            throw new UserNotFoundException();
        }
    }

}
