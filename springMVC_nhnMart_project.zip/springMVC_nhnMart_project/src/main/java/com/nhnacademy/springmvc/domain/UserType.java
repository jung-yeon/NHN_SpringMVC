package com.nhnacademy.springmvc.domain;

public enum UserType {
    CS,CUSTOMER
}
