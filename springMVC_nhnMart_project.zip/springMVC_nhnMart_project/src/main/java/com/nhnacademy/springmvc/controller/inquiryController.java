package com.nhnacademy.springmvc.controller;

import com.nhnacademy.springmvc.domain.Inquiry;
import com.nhnacademy.springmvc.exception.InquiryNotFoundException;
import com.nhnacademy.springmvc.repository.InquiryRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.nio.file.Paths;
import java.util.Objects;

@Slf4j
@Controller
@RequestMapping("/customer")
public class inquiryController {

    private InquiryRepository inquiryRepository;

    @GetMapping("/inquiry")
    public String viewPost(@ModelAttribute("inquiry") Inquiry inquiry,
                           ModelMap modelMap) {
        if (Objects.isNull(inquiry)) {
            modelMap.put("exception", new InquiryNotFoundException());
            return "inquiryForm";
        }

        modelMap.put("inquiry", inquiry);
        return "inquiryRegister";
    }


//    private static final String UPLOAD_DIR = request.getRequestURI();


    @PostMapping("/inquiry")
    public String postInquiry(
            @RequestParam("inquiryId") long id,
            @RequestParam("title") String title,
            @RequestParam("file") MultipartFile file,
            @RequestParam("content") String content,
            HttpServletRequest request,
            Model model) throws IOException {
        String UPLOAD_DIR = request.getRequestURI();
        inquiryRepository.register(id, title, file ,content);
        file.transferTo(Paths.get(UPLOAD_DIR + file.getOriginalFilename()));
        model.addAttribute("inquiryId", id);
        model.addAttribute("title", title);
        model.addAttribute("file", file.getOriginalFilename());
        model.addAttribute("content", content);
        return "inquiryForm";
    }
}
