package com.nhnacademy.springmvc.repository;

import com.nhnacademy.springmvc.domain.Inquiry;
import org.springframework.web.multipart.MultipartFile;

import java.util.*;
import java.util.function.Function;

public class InquiryRepositoryImpl implements InquiryRepository{
    private final Map<Long, Inquiry> inquirys = new HashMap<>();
    private ArrayList<Inquiry> inquiryList = new ArrayList<>();
    @Override
    public boolean exists(long id) {
        return inquirys.containsKey(id);
    }

    @Override
    public Inquiry register(long id, String title, MultipartFile file, String content) {

        Inquiry inquiry = Inquiry.create(id, title, file, content);
        inquiry.setId(id);
        inquirys.put(id, inquiry);

        return inquiry;
    }
    @Override
    public Inquiry getInquiry(long id) {
        return exists(id) ? inquirys.get(id) : null;
    }

    @Override
    public ArrayList<Inquiry> getInquiryList() {
        Set<Long> keySet = inquirys.keySet();
        for (Long key : keySet) {
             inquiryList.add(inquirys.get(key));
        }
        return inquiryList;
    }

}
