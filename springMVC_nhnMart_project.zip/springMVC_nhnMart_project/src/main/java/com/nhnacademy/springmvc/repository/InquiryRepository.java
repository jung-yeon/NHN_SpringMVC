package com.nhnacademy.springmvc.repository;

import com.nhnacademy.springmvc.domain.Inquiry;
import org.springframework.web.multipart.MultipartFile;

import java.util.ArrayList;

public interface InquiryRepository {
    boolean exists(long id);


    Inquiry register(long id, String title, MultipartFile file, String content);

    Inquiry getInquiry(long id);

    ArrayList getInquiryList();
}
